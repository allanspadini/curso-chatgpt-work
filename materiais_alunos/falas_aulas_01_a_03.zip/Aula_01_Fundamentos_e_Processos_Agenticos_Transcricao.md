# Apostila de Transcrição e Conteúdo Narrado — Aula 1

**Instituição:** Instituto Infnet — Pós-Graduação EAD  
**Curso:** Pós-Graduação EAD em Inteligência Artificial e Engenharia de Software  
**Disciplina:** Processos Agênticos com ChatGPT Work [26E4_2]  
**Professor:** Prof. Dr. Allan Segovia-Spadini  
**Tema da Aula:** Fundamentos de IA, Mudança de Paradigma e Engenharia de Workflows Agênticos  
**Material de Apoio ao Estudante:** Transcrição na íntegra das explicações do docente para cada slide, desenvolvida para leitura linear, fixação conceitual e consulta durante a execução dos projetos práticos.

---

## Sumário da Aula

1. **Slide 1:** Processos Agênticos com ChatGPT Work (Abertura Oficial)
2. **Slide 2:** Apresentação do Docente
3. **Slide 3:** Roadmap da Aula 1: Trilha Pedagógica
4. **Slide 4:** A Ilusão da Fluência: O Colapso dos Prompts Pontuais
5. **Slide 5:** A Natureza dos LLMs: Padrões Estatísticos sem Consciência
6. **Slide 6:** Os 4 Hábitos Duráveis da Interação com IA
7. **Slide 7:** O Prompt como Especificação de Trabalho (Work Specification)
8. **Slide 8:** As 4 Propriedades do Contexto Forte
9. **Slide 9:** Laboratório Interativo 1: Inspetor de Contexto
10. **Slide 10:** O Gargalo Conversacional: A Prisão do Turno a Turno
11. **Slide 11:** A Grande Virada: De Conversação a Desfecho Delegado
12. **Slide 12:** Do Contexto Fornecido ao Contexto Conectado
13. **Slide 13:** Laboratório Interativo 2: Comparador Chat vs. Work
14. **Slide 14:** O Contrato do Agente: Os 4 Pilares de Delegação
15. **Slide 15:** Laboratório Interativo 3: Construtor de Contratos
16. **Slide 16:** Modelagem de Workflows antes da Automação
17. **Slide 17:** O Princípio da Reversibilidade e Portões HITL
18. **Slide 18:** Laboratório Interativo 4: Matriz de Reversibilidade
19. **Slide 19:** Revisão Estruturada em 6 Camadas (Layered Review)
20. **Slide 20:** A Esteira de Evolução Agêntica em 4 Estágios
21. **Slide 21:** Laboratório Interativo 5: Quiz de Fixação e Avaliação Formativa

---

## Slide 1 — Processos Agênticos com ChatGPT Work
**Subtítulo:** Aula 1: Fundamentos de IA, Mudança de Paradigma e Engenharia de Workflows Agênticos

Sejam muito bem-vindos à nossa pós-graduação no Instituto Infnet. Eu sou o Professor Allan Spadini e hoje iniciamos a disciplina de Processos Agênticos com ChatGPT Work, sob o código [26E4_2].

Esta aula inaugural marca uma transição essencial de maturidade técnica e profissional. Nos últimos anos, o mercado se acostumou a interagir com modelos de linguagem como meros assistentes de bate-papo: você digita uma dúvida, recebe um texto, tenta corrigir no turno seguinte e faz o trabalho braçal de copiar, colar e formatar os dados.

O ChatGPT Work, integrado à infraestrutura do Codex e aos conectores corporativos da OpenAI, representa uma ruptura estrutural com essa dinâmica ingênua. Não estamos mais lidando apenas com um bot que responde a turnos de conversa. Estamos projetando e operando agentes autônomos orientados a desfechos — isto é, sistemas capazes de receber um contrato de delegação bem definido, consultar ferramentas autenticadas onde o trabalho da empresa realmente reside, raciocinar em múltiplas etapas intermediárias e devolver um artefato pronto, auditável e homologável.

Ao longo desta disciplina, construiremos uma ponte rigorosa entre a teoria probabilística dos modelos de linguagem e a engenharia de software aplicada a fluxos corporativos. Vamos aprender a especificar o trabalho com precisão cirúrgica, a delimitar o contexto para erradicar o ruído, a calibrar a autonomia do agente com base no Princípio da Reversibilidade e a instituir portões de auditoria humana onde a responsabilidade legal e operacional for decisiva. Vamos dar início à nossa jornada!

---

## Slide 2 — Apresentação do Docente
**Subtítulo:** Prof. Dr. Allan Segovia-Spadini • Trajetória Acadêmica e Atuação em Engenharia de IA

Gostaria de me apresentar formalmente para que vocês conheçam a bagagem acadêmica e prática que sustentará nossas aulas.

Sou o Allan Segovia-Spadini. Minha formação de pós-graduação foi construída no Instituto de Astronomia, Geofísica e Ciências Atmosféricas da Universidade de São Paulo (USP), onde concluí meu mestrado e meu doutorado em Ciências na área de Geofísica Aplicada e Computacional, com período de estágio de doutorado sanduíche na Delft University of Technology (TU Delft), na Holanda. 

Minha atuação profissional e de pesquisa concentra-se na modelagem estatística, Machine Learning, Deep Learning e na engenharia de sistemas agênticos com Grandes Modelos de Linguagem. Aqui na Faculdade Infnet, conduzo com muito orgulho esta disciplina avançada de Processos Agênticos com ChatGPT Work.

O meu compromisso com vocês é claro: não ficaremos em 'receitas de bolo' superficiais ou dicas mágicas de prompt. Trataremos os modelos agênticos com rigor de engenharia: entendendo a matemática por trás da amostragem, modelando os grafos de tarefas, programando conectores seguros e implementando governança empresarial sólida.

---

## Slide 3 — Roadmap da Aula 1: Trilha Pedagógica
**Subtítulo:** Da Teoria Probabilística à Orquestração de Agentes Orientados a Desfechos

Vejamos o mapa de navegação da nossa aula de hoje. Para estruturar o conteúdo de forma sólida, dividimos nossa sessão em 4 blocos interdependentes:

No **Módulo 1 — Fundamentos de IA e a Natureza dos LLMs** —, começamos pela dor prática da indústria: por que prompts pontuais falham miseravelmente em ambientes corporativos? Analisaremos o mecanismo autorregressivo de predição de tokens e formalizaremos os 4 hábitos duráveis da nossa metodologia de engenharia de interação com IA.

No **Módulo 2 — A Grande Virada: Chat vs. Work** —, investigaremos o gargalo da orquestração manual turno a turno. Veremos a ruptura que o ChatGPT Work traz ao mudar a unidade de delegação de 'turn' para 'outcome', bem como a transição do contexto fornecido estático para o contexto conectado via plugins e conectores corporativos.

No **Módulo 3 — Engenharia de Contratos e Mapeamento de Workflows** —, aprenderemos a modelar o fluxo de negócio antes de encostar em qualquer ferramenta de IA. Dissecaremos os 4 pilares do Contrato Agêntico: Desfecho, Contexto, Restrições e Critérios de Aceitação.

Por fim, no **Módulo 4 — Reversibilidade, Governança e Maturidade** —, formalizaremos o Princípio da Reversibilidade para calibrar a autonomia do agente, desenharemos portões Human-in-the-Loop (HITL), aprenderemos o protocolo de revisão em 6 camadas e traçaremos a esteira de maturidade agêntica em 4 fases.

Em cada bloco, contaremos com laboratórios visuais e simuladores interativos para fixar os conceitos com aplicação prática direta.

---

## Slide 4 — A Ilusão da Fluência: O Colapso dos Prompts Pontuais
**Subtítulo:** Situação-Problema do Mundo Real • A Dor Prática da Eloquência sem Ancoragem

Vamos iniciar com a nossa Situação-Problema do Mundo Real: por que a abordagem amadora de 'tentar prompts criativos' quebra tão rápido quando levada para fluxos de negócio na indústria?

A primeira grande dor prática enfrentada por equipes corporativas é o que chamamos de 'A Ilusão da Fluência'. Quando um analista digita um prompt vago como 'analise estas propostas e me dê um relatório', o modelo responde com parágrafos elegantes, vocabulário rebuscado, excelente coesão gramatical e um tom extremamente assertivo. O cérebro humano é evolutivamente treinado para associar eloquência verbal à competência técnica e veracidade factual.

Contudo, ao inspecionar os detalhes, surgem alucinações silenciosas: números trocados, premissas não informadas inventadas pelo modelo, metas obsoletas aplicadas como vigentes e citações fantasmas. 

O resultado operacional é devastador: o operador humano gasta mais horas checando cada linha, tentando detectar inconsistências sutis e reescrevendo comandos do que gastaria redigindo o relatório por conta própria. Gera-se uma fadiga extrema do operador, associada a uma tremenda fragilidade de execução: se uma palavra for alterada no prompt no dia seguinte, a saída pode mudar de forma imprevisível.

Essa dor prática prova que prompts pontuais não sustentam processos de negócios. Precisamos de especificações formais de trabalho e ancoragem factual inegociável.

---

## Slide 5 — A Natureza dos LLMs: Padrões Estatísticos sem Consciência
**Subtítulo:** Formalismo Teórico • Amostragem Autorregressiva vs. Sistemas de Registro

Para solucionar esse problema com mentalidade de engenharia, precisamos entender o que um modelo de linguagem realmente é por baixo do capô.

Matematicamente, um Large Language Model opera sob o mecanismo autorregressivo de previsão do próximo token. Dada uma sequência de entrada composta pelo prompt e pelo histórico de contexto $C$, a rede projeta os estados ocultos em logits $z_t$ no espaço do vocabulário e calcula uma distribuição de probabilidade através de uma função softmax escalada por uma temperatura $\tau$:

$$P(w_t \mid w_1, \dots, w_{t-1}, C) = \text{softmax}\left(\frac{z_t}{\tau}\right)$$

O modelo otimiza exclusivamente a verossimilhança estatística de padrões linguísticos que ele observou em petabytes de dados de pré-treinamento. Ele não 'sabe' o que é um balanço patrimonial, ele não tem experiência de chão de fábrica, ele não possui responsabilidade civil ou legal sobre uma decisão equivocada, e ele não possui nenhuma consciência situacional dos stakeholders da sua empresa, a menos que você forneça essa informação de forma estruturada.

Por isso, guardem com vocês a Regra de Ouro da disciplina: **'Confiança de Expressão não é evidência de Exatidão Factual'**. A segurança e o tom firme da resposta decorrem apenas da convergência probabilística dos pesos neurais. A exatidão factual, por outro lado, decorre unicamente da ancoragem estrita em fontes e evidências autoritativas.

---

## Slide 6 — Os 4 Hábitos Duráveis da Interação com IA
**Subtítulo:** Solução de Engenharia • Os 4 Hábitos Duráveis da Interação Corporativa

Como contornamos a limitação probabilística dos modelos e garantimos previsibilidade em ambiente de produção? A resposta da engenharia reside na adoção de quatro hábitos duráveis, estabelecidos nas melhores práticas de engenharia agêntica:

- **Hábito 1: Instruções Claras.** Em vez de comandos vagos ou subjetivos, tratamos cada interação como uma especificação compacta de trabalho, definindo meta, público, formato e limites.
- **Hábito 2: Contexto Delimitado.** Mais arquivos não geram uma resposta melhor; geram ruído e contradições cognitivas. O contexto deve ser selecionado cirurgicamente, priorizando fontes oficiais e declarando a precedência entre elas.
- **Hábito 3: Revisão em Camadas.** Não fazemos um 'olhar rápido de diagramação'. Conduzimos uma auditoria estruturada: confrontando números contra as fontes, caçando omissões de casos extremos e separando fatos verificados de inferências feitas pela IA.
- **Hábito 4: Uso Responsável Situacional.** Governança aplicada caso a caso. Avaliamos a sensibilidade dos dados, as políticas de conformidade do workspace corporativo e o impacto potencial de erro em cada etapa do processo.

Para enxergar o poder desses quatro hábitos, vejamos o caso de uma transcrição de reunião real de alinhamento logístico entre Carlos, Mariana e Roberto: Mariana rescinde com a TransLog e migra para a RápidoExpress até 22 de agosto; Roberto aprova orçamento emergencial de R$ 45.000; Carlos propõe RFID nas docas e Mariana propõe turno da madrugada, mas não há responsável nem prazo definidos para a cotação; e a licença ambiental de Curitiba segue travada no jurídico.

Se o analista digitar o prompt informal típico: *'Resuma tudo e monte o relatório executivo.'*, o modelo entrará em colapso nos 4 hábitos: não saberá o formato exigido pela diretoria, alucinará premissas não ditas, tratará meras sugestões como se fossem decisões aprovadas (gerando desinformação operacional) e criará minutas externas sem salvaguarda de governança.

Em contrapartida, vejam a especificação de engenharia adotando os 4 hábitos:
1. **Instruções Claras:** Relatório de 1 página para a Diretoria estruturado em 4 seções fixas (Decisões Homologadas, Ações/Prazos/Responsáveis, Propostas em Avaliação, Questões em Aberto).
2. **Contexto Delimitado:** Confinado estritamente à transcrição, declarando 'Pendente / Não especificado' onde não houver responsável ou prazo.
3. **Revisão em Camadas:** Rastreamento estrito de valores (R$ 45.000 e prazo de 22/08) e isolamento da pendência da licença jurídica.
4. **Uso Responsável:** Uso interno restrito, proibindo minutas ou contatos externos sem aprovação prévia.

Ao examinarmos o relatório gerado sob esses preceitos, observamos a precisão cirúrgica do entregável: zero ambiguidade, total rastreabilidade e prontidão imediata para tomada de decisão pela liderança.

---

## Slide 7 — O Prompt como Especificação de Trabalho (Work Specification)
**Subtítulo:** Engenharia de Instrução • Substituindo Perguntas Vagas por Contratos Executáveis

Vamos dissecar o primeiro hábito: transformar o prompt em uma verdadeira Especificação de Trabalho — uma 'Work Specification'.

Reparem no contraste gritante. Quando alguém escreve: *'Resuma as notas da reunião de ontem'*, o modelo é forçado a assumir premissas não declaradas. Ele não sabe quem vai ler, qual decisão estratégica depende desse resumo, quais dados são confidenciais e quais são irrelevantes. Ele gera um texto prolixo e inútil para a diretoria.

Agora observem a Especificação de Trabalho rigorosa: *'Com base apenas nas notas anexas, gere um briefing de decisão de 1 página para o Diretor de Operações. Separe decisões confirmadas de propostas abertas. Identifique responsável e prazo de cada ação. Indique 'não especificado' quando faltar dado. Finalize com tabela de rastreabilidade de fontes.'*

Uma boa especificação responde compulsoriamente a 6 perguntas fundamentais:
1. Qual o desfecho concreto (Outcome)?
2. Quem é a audiência e qual ação ou decisão depende do documento?
3. Quais são as fontes de verdade autorizadas?
4. Quais são as fronteiras estritas de escopo e inclusões/exclusões?
5. Qual a mídia e o formato estrutural esperado?
6. Como o auditor humano inspecionará o resultado?

Quando a especificação é bem construída, não dependemos de adivinhações do modelo.

---

## Slide 8 — As 4 Propriedades do Contexto Forte
**Subtítulo:** Teoria e Prática de Engenharia de Contexto • Sinal vs. Ruído nos LLMs

Passamos agora ao segundo hábito: o gerenciamento de contexto. Em engenharia de sistemas agênticos, há uma armadilha clássica: achar que quanto maior a janela de contexto do modelo, mais arquivos devemos anexar indiscriminadamente. Isso é um erro grave que degrada a atenção do Transformer e eleva exponencialmente o risco de alucinação.

Um conjunto de contexto forte deve possuir rigorosamente quatro propriedades:

- **Primeira: Autoritativo.** As informações devem ser provenientes dos sistemas oficiais de registro da organização — ERP, atas homologadas, repositórios auditados —, nunca de notas soltas ou rascunhos informais.
- **Segunda: Atual.** A vigência temporal de cada arquivo deve estar explícita. Se você anexar uma diretriz de 2023 junto a uma de 2026 sem rotular as datas, o modelo pode fundir as duas ou aplicar uma regra revogada.
- **Terceira: Delimitado (Scoped).** Selecione apenas a evidência que altera a decisão. Trechos cirúrgicos eliminam contradições e mantêm o modelo focado no que importa.
- **Quarta: Interpretável.** As siglas corporativas, convenções contábeis e nomenclaturas internas devem ser mapeadas em um glossário claro para evitar falsas inferências semânticas.

E lembrem-se da nossa regra de governança para conflitos: se duas fontes oficiais divergirem, exija que a IA aponte a contradição explicitamente em vez de forçar um consenso artificial.

---

## Slide 9 — Laboratório Interativo 1: Inspetor de Contexto
**Subtítulo:** Simulador Dinâmico • Avaliação de Fidelidade, Conflitos e Risco de Alucinação

No nosso primeiro laboratório prático, o Inspetor de Contexto, modelamos uma demanda executiva real: a geração de um briefing de orçamento para expansão de infraestrutura de TI, avaliando as 4 propriedades do contexto: Autoritativo, Atual, Delimitado e Interpretável.

Ao desligarmos a propriedade 'Atual', a fidelidade cai imediatamente e o modelo aplica o teto orçamentário obsoleto de 2023, criando um passivo financeiro na proposta!

Ao desligarmos 'Autoritativo', o agente passa a citar opiniões colhidas em fóruns informais como se fossem políticas deliberadas pela diretoria.

Quando as 4 propriedades estão ativas simultaneamente, a fidelidade atinge 100%, os números são estritamente ancorados na ata oficial e os dados ausentes são rotulados honestamente como 'não especificado'.

Essa dinâmica ilustra por que o papel do engenheiro de IA em ChatGPT Work não é 'escrever texto bonito', mas sim atuar como um curador implacável da qualidade da evidência fornecida ao sistema.

---

## Slide 10 — O Gargalo Conversacional: A Prisão do Turno a Turno
**Subtítulo:** Situação-Problema do Mundo Real • A Fadiga do Operador como Barramento Manual de Dados

Vamos examinar agora a segunda grande dor prática da indústria, que prepara o terreno para a introdução do ChatGPT Work: o gargalo do modelo conversacional tradicional, ou a 'Prisão do Turno a Turno' (*Turn Trap*).

No uso cotidiano de interfaces de chat simples, o usuário humano acaba virando um 'escravo operacional' do fluxo de trabalho. Observem o ciclo:
- No **turno 1**, você faz uma pergunta preliminar. A IA responde de forma genérica.
- No **turno 2**, você precisa sair da janela do chat, abrir o Google Drive da empresa, encontrar a proposta comercial mais recente, baixá-la no disco, voltar ao chat e anexar o PDF.
- No **turno 3**, você nota que a IA usou valores errados, então você abre o Slack, copia as discussões recentes da equipe de engenharia e cola outro bloco de texto pedindo correções.
- No **turno 4**, o modelo gera uma tabela longa em texto, mas você ainda tem que copiar aquilo, abrir o Word ou o Excel e diagramar o relatório final manualmente.

Percebam a ironia: a IA gerou o texto em frações de segundo, mas o fluxo inteiro de trabalho demorou 40 minutos porque o operador humano foi o barramento manual de dados entre ferramentas e o agendador de tarefas.

É exatamente esse gargalo que o ChatGPT Work foi projetado para eliminar.

---

## Slide 11 — A Grande Virada: De Conversação a Desfecho Delegado
**Subtítulo:** Solução de Engenharia • Arquitetura Comparativa: Chat vs. ChatGPT Work

Chegamos ao ponto de inflexão da nossa aula: a grande virada de paradigma entre o Chat tradicional e o ChatGPT Work.

No **Chat tradicional**, a unidade de trabalho é o **Turno (Turn)**. Cada interação exige que o humano analise a saída, decida o próximo passo, forneça novos dados e mantenha o raciocínio na própria cabeça. É um ambiente fantástico para brainstorming, exploração aberta de ideias e redação de e-mails rápidos.

No **ChatGPT Work**, a unidade de trabalho é o **Desfecho (Outcome)**. O agente recebe a responsabilidade de conduzir um processo multi-etapas com início, meio e fim. Ele elabora internamente um plano de execução, consulta as ferramentas conectadas homologadas, inspeciona arquivos estruturados, valida suas próprias etapas e entrega um artefato completo — uma planilha auditada, uma apresentação com narrativa consistente ou um relatório técnico.

Reparem que isso não elimina o julgamento humano. Pelo contrário: eleva o julgamento humano para o nível estratégico. Em vez de perder tempo com micro-comandos de cópia e cola, o profissional passa a definir o Contrato de Trabalho, estabelecer as fronteiras de segurança e auditar o artefato final entregue pelo agente.

---

## Slide 12 — Do Contexto Fornecido ao Contexto Conectado
**Subtítulo:** Engenharia de Sistemas • Integração Autenticada via Plugins e Conectores Corporativos

Para que um agente consiga entregar um desfecho autônomo na prática corporativa, ele não pode depender de uploads manuais em cada sessão. É aqui que entra a evolução do 'Contexto Fornecido' para o 'Contexto Conectado'.

O **Contexto Fornecido** é estático: você pega um arquivo que está no seu computador e sobe para o chat. Ele representa apenas um retrato congelado naquele minuto. Se um colega de equipe atualizar a proposta no Drive dez minutos depois, o chat continuará operando sobre a versão velha.

O **ChatGPT Work** introduz o **Contexto Conectado** por meio de Plugins e Conectores de Workspace. O agente conecta-se via OAuth autenticado diretamente aos repositórios onde o trabalho corporativo acontece: Google Drive (Docs, Sheets, Slides), Slack, Teams, Jira, GitHub e bancos de dados institucionais.

Mais importante ainda: toda essa conectividade opera sob rigorosa governança empresarial. O plugin não dá ao agente acesso irrestrito; ele herda com exatidão os privilégios do usuário logado e as políticas de segurança da organização. Além disso, adotamos a regra de engenharia de priorizar ações estritamente de leitura (*read-only*) em fases iniciais, impedindo alterações acidentais em arquivos compartilhados.

---

## Slide 13 — Laboratório Interativo 2: Comparador Chat vs. Work
**Subtítulo:** Simulador Dinâmico • Comparação de Esforço Cognitivo, Fluxo de Estados e Automação

No laboratório interativo do Comparador Chat vs. Work, contrastamos o esforço em casos reais como o Onboarding Enterprise e Briefing Executivo:

No modo **Chat**, o humano precisa intervir em cada um dos múltiplos turnos: subindo arquivos, pedindo correções, copiando textos e diagramando na mão. O risco de fadiga é altíssimo.

No **ChatGPT Work**, o operador dispara um único contrato estruturado com menções aos conectores necessários (@Google Drive e @Slack). O agente assume a execução em cadeia: localiza o arquivo mais recente, cruza as decisões pendentes, produz o artefato nativo e estaciona com segurança no portão de homologação humana.

O tempo economizado chega a 75%, e o índice de rastreabilidade salta para 100%. É essa a diferença entre 'brincar de conversar com a IA' e 'delegar trabalho com padrão de engenharia'.

---

## Slide 14 — O Contrato do Agente: Os 4 Pilares de Delegação
**Subtítulo:** Engenharia de Contratos • A Estrutura Formal de Delegação Agêntica

Como garantimos que o agente execute exatamente o que a organização precisa, sem fugir do escopo ou tomar decisões perigosas? A resposta da engenharia é o Contrato do Agente (*Agent's Contract*), desenvolvido na nossa metodologia de governança agêntica.

Um contrato de delegação substitui suposições por quatro pilares formais e inegociáveis:

1. **Desfecho (Outcome):** O estado final acabado e observável. Nunca instrua com verbos vagos como 'pense sobre o projeto'. Declare o artefato: 'Um plano de marcos e riscos em Markdown com 5 seções estruturadas'.
2. **Contexto (Context):** Todas as fontes oficiais e parâmetros de negócio que o agente necessita para interpretar as regras: atas homologadas, canal de comunicação aprovado, personas e definições de métricas.
3. **Restrições (Constraints):** As fronteiras operacionais e 'linhas vermelhas'. O agente deve saber o que NÃO pode fazer: não alterar registros mestres, não disparar comunicações externas a terceiros e rotular omissões como 'não especificado'.
4. **Critérios de Aceitação (Acceptance Criteria):** A lista de checagem objetiva que o revisor humano usará para homologar a entrega: 100% dos dados rastreados à evidência, todas as premissas identificadas e formatação conforme o padrão da empresa.

Essa formalização contratual transforma a IA de uma caixa preta instável em um executor confiável e auditável.

---

## Slide 15 — Laboratório Interativo 3: Construtor de Contratos
**Subtítulo:** Simulador Dinâmico • Montagem e Validação de Especificações Agênticas Seguras

No Construtor e Validador de Contratos Agênticos, avaliamos cláusulas fracas versus cláusulas fortes de engenharia para cada um dos 4 pilares: Outcome, Context, Constraints e Acceptance Criteria.

Quando cláusulas fracas são inseridas, o índice de solidez contratual despenca: o agente fica sem limites de escopo, vasculha pastas irrelevantes ou produz relatórios opinativos sem dados rastreáveis.

Ao selecionar opções com padrão de engenharia, o índice atinge pontuação máxima, compilando uma especificação de contrato completa em Markdown, pronta para ser copiada e utilizada em fluxos reais do ChatGPT Work.

Esse é o padrão de excelência que vocês devem exigir em qualquer projeto agêntico corporativo.

---

## Slide 16 — Modelagem de Workflows antes da Automação
**Subtítulo:** Arquitetura de Processos • O Grafo Formal de 7 Etapas

Antes de encostar em qualquer ferramenta de IA ou ativar qualquer automação, existe um mandamento que nenhum engenheiro pode violar: **'Automatizar um processo confuso e caótico apenas reproduz a ambiguidade em maior velocidade'**.

Antes de delegar ao agente, precisamos mapear e simplificar a mecânica do processo em 7 etapas mínimas:
1. **Gatilho (Trigger):** Qual é o evento ou cronograma que dispara a necessidade da execução?
2. **Fontes de Entrada:** Quais são os sistemas de registro e arquivos que contêm a evidência oficial?
3. **Transformações e Decisões:** Quais operações lógicas, filtros, cruzamentos e regras de negócio devem ocorrer?
4. **Aprovações Humanas (HITL):** Onde estão os pontos críticos que exigem autorização humana antes de prosseguir?
5. **Checagens de Aceite:** Quais testes validam que a saída atende aos requisitos de qualidade?
6. **Saída e Audiência:** Qual é o artefato final entregue e quem é o consumidor daquela informação?
7. **Responsável Final (Owner):** Quem é o profissional humano que assina o entregável e responde pelo resultado perante a governança?

Se o seu processo contiver etapas manuais obsoletas ou regras não documentadas, conserte o processo primeiro. Só depois construa o contrato agêntico.

---

## Slide 17 — O Princípio da Reversibilidade e Portões HITL
**Subtítulo:** Governança & Segurança • Concedendo Autonomia em Proporção Direta ao Risco

Nem todas as ações de um fluxo de trabalho corporativo possuem o mesmo perfil de risco. Como desenhar a autoridade do agente para que ele seja veloz sem colocar a empresa em risco jurídico ou financeiro?

A resposta formal de engenharia é o **Princípio da Reversibilidade**: **'Conceda autonomia em proporção direta à reversibilidade da operação'**.

- **Alta Reversibilidade e Baixo Risco:** Ler documentos, pesquisar bases públicas, sintetizar rascunhos em arquivos locais e gerar tabelas comparativas. Se o modelo cometer um erro nessas tarefas, o impacto é nulo: basta descartar o rascunho e refazer. Para essas operações, concedemos **Autonomia Total** e execução contínua ao agente.
- **Baixa Reversibilidade e Alto Impacto:** Enviar e-mails para clientes, sobrescrever registros em bancos de produção ou ERPs, debitar APIs pagas e aprovar despesas. Se o agente errar aqui, o estrago pode ser irreparável. Para essas operações, é mandatório instituir um **Portão Humano (Human-in-the-Loop - HITL)**, onde o agente é obrigado a pausar e aguardar confirmação explícita.

Essa dosagem é o que distingue uma automação madura de uma aventura perigosa.

---

## Slide 18 — Laboratório Interativo 4: Matriz de Reversibilidade
**Subtítulo:** Simulador Dinâmico • Calibração de Autonomia, Portões HITL e Risco Operacional

No laboratório da Matriz de Reversibilidade e Autonomia, analisamos cinco ações corporativas cotidianas ordenadas por impacto: leitura de arquivos, síntese de rascunhos, criação de arquivos internos, atualização de CRM e disparo de e-mails para clientes externos.

Ao forçar 'Portão HITL' em ações rotineiras de baixa gravidade (leitura e síntese), cria-se 'Fadiga por Microgerenciamento': o operador humano é interrompido a cada leitura simples, destruindo os ganhos de produtividade da IA.

Ao marcar 'Autônomo' em ações irreversíveis (alteração de CRM e disparo de e-mails), surge 'Risco Crítico de Governança', dando carta branca para a IA alterar dados mestres sem supervisão.

A calibração ótima equilibra autonomia nas fases de rascunho e investigação com portões obrigatórios nas ações de borda externa.

---

## Slide 19 — Revisão Estruturada em 6 Camadas (Layered Review)
**Subtítulo:** Auditoria de Entregáveis • A Metodologia de Inspeção Sistemática

Quando o agente conclui a execução e devolve o artefato para homologação, como o revisor humano deve conduzir a auditoria?

Nunca faça uma 'leitura diagonal de formatação'. Adotamos na disciplina a **Revisão Estruturada em 6 Camadas**:

- **Camada 1: Adequação e Público.** O documento responde à pergunta formulada e atende às necessidades estratégicas daquela audiência específica?
- **Camada 2: Checagem Fonte-Dado.** Esta é a camada técnica mais rigorosa: cada número, data, citação ou valor financeiro presente no texto é confrontado diretamente contra o arquivo fonte oficial.
- **Camada 3: Completude e Casos Extremos.** O relatório considerou todas as categorias, departamentos ou cenários, ou omitiu dados silenciosamente?
- **Camada 4: Validação de Premissas e Raciocínio.** Fatos comprovados estão claramente separados de interpretações e hipóteses sugeridas pelo modelo?
- **Camada 5: Inspeção na Mídia Final.** Como o documento se comporta em sua mídia de destino? Há links quebrados, colunas cortadas ou descontinuidade visual?
- **Camada 6: Autorização de Ações Externas.** Qualquer ação com efeitos colaterais externos foi homologada por um profissional legalmente responsável?

Essa auditoria em camadas garante conformidade irrestrita e constrói confiança institucional na IA.

---

## Slide 20 — A Esteira de Evolução Agêntica em 4 Estágios
**Subtítulo:** Maturidade Organizacional • Da Tarefa Guiada à Operação Monitorada em Escala

Para fechar nossa fundamentação teórica, precisamos enxergar a esteira de maturidade organizacional na adoção de processos agênticos. Toda equipe deve percorrer quatro estágios progressivos:

- **Estágio 1: Tarefa Guiada (Guided Task).** O profissional humano atua como mentor próximo: fornece os documentos manualmente, supervisiona cada passo intermediário e valida os raciocínios turno a turno.
- **Estágio 2: Entregável Delegado (Delegated Deliverable).** O humano formula um contrato completo e delega o desfecho. O agente realiza a execução multi-etapas de forma autônoma e devolve o artefato para auditoria.
- **Estágio 3: Fluxo Reutilizável (Reusable Workflow).** As instruções, templates, conectores e critérios de aceite são empacotados em 'Skills' institucionais e Projects no ChatGPT Work, permitindo que qualquer membro da equipe execute a tarefa com qualidade idêntica.
- **Estágio 4: Operação Monitorada (Monitored Operation).** O fluxo opera acionado por gatilhos ou cronogramas recorrentes, com trilha de auditoria persistente, portões HITL automatizados e monitoramento periódico de métricas de sucesso.

A regra de ouro da maturidade é: **'Nunca dê o salto direto para o Estágio 4'**. Um fluxo automatizado que não foi provado e depurado nos estágios guiados é uma bomba-relógio corporativa.

---

## Slide 21 — Laboratório Interativo 5: Quiz de Fixação e Avaliação Formativa
**Subtítulo:** Avaliação Formativa • 4 Questões de Alto Nível de Pós-Graduação com Feedback Imediato

Chegamos ao final da nossa primeira aula com o nosso Quiz de Fixação e Avaliação Formativa de Competências, abordando diretamente os pontos centrais que discutimos hoje:
1. A mudança estrutural na unidade de delegação entre o Chat tradicional e o ChatGPT Work.
2. A mecânica probabilística dos LLMs e por que confiança de expressão não prova exatidão factual.
3. A aplicação prática do Princípio da Reversibilidade na governança de portões Human-in-the-Loop.
4. As quatro propriedades fundamentais de um conjunto de contexto forte.

Aproveitem este material para consolidar os conceitos fundamentais. Na nossa Aula 2, entraremos a fundo na configuração de agentes com AGENTS.md e na arquitetura de subagentes concorrentes. Bons estudos a todos!
